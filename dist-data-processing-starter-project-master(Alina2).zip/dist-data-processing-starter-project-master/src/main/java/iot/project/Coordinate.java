package iot.project;

public class Coordinate {
	private String latitude, longitude;

	public Coordinate(String latitude, String longitude) {		
		this.latitude = latitude;
		this.longitude = longitude;
	}
	
	@Override
	public String toString() {
		return latitude + " " + longitude;
	}
}
