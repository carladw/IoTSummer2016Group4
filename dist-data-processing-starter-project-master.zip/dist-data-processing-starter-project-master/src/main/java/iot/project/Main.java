package iot.project;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.uniluebeck.itm.util.logging.Logging;

public class Main {
	static int webServerPort = 8080;
	// new
	static List<Coordinate> coordinateList = new ArrayList<>();

	static {
		Logging.setLoggingDefaults();
	}

	public static void main(String[] args) {
		// Obtain an instance of a logger for this class
		Logger log = LoggerFactory.getLogger(Main.class);
		
		

		// Start a web server
		setupWebServer(webServerPort);
		log.info("Web server started on port " + webServerPort);
		log.info("Open http://localhost:" + webServerPort + " and/or http://localhost:" + webServerPort + "/hello");

		// Do your stuff here

	}
	
	public static void setupWebServer(int webServerPort) {
        // Set the web server's port
        spark.Spark.port(webServerPort);

        // Serve static files from src/main/resources/webroot
        spark.Spark.staticFiles.location("/webroot");

        // Return "Hello World" at URL /hello
        spark.Spark.get("/hello", (req, res) -> "Hello World");

        // http://localhost:8080/status?lat=32&long=31
        spark.Spark.get("/status", (req, res) -> {
            String latitude = req.queryParams("lat");
            String longitude = req.queryParams("long");

            coordinateList.add(new Coordinate(latitude, longitude));
            System.out.println("lat = " + latitude + " long = " + longitude);
            
            for (Coordinate c : coordinateList){
            	
            	System.out.println("Coordinate: " + c);
            }

            return "{ }";
        });

        // Wait for server to be initialized
        spark.Spark.awaitInitialization();
    }

}
